"""
src/app.py — Web API + UX server for Canada Immigration & PR Navigator

Owner: Ehraaz Atif (Role E — Integration & UX)
Wraps IntakeStateMachine + run_pipeline in an HTTP API for the web frontend.

Endpoints:
    POST /api/session          — Create a new intake session
    POST /api/chat             — Process one conversation turn
    GET  /api/session/<id>     — Get current session state (profile + state)
    GET  /api/health           — Health check

Run:
    python -m src.app
    (or: flask --app src.app run --port 5050)
"""

from __future__ import annotations

import uuid
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory

load_dotenv()

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

WEB_DIR = Path(__file__).resolve().parent.parent / "web"

app = Flask(__name__, static_folder=str(WEB_DIR), static_url_path="")


# ---------------------------------------------------------------------------
# In-memory session store
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Answer text cleaning
# ---------------------------------------------------------------------------

def _clean_answer_text(text: str) -> str:
    """Strip LLM-injected citation JSON blocks and warning suffixes from the
    answer body.  These are already surfaced as structured fields by the API
    (citations[], confidence_warning, disclaimer) so they should not appear
    verbatim in the prose the user reads.

    Patterns removed:
      - Inline citation JSON objects  { "source_url": ... }
      - Lines starting with [LOW CONFIDENCE] or [DATA COLLECTION MODE]
      - The trailing disclaimer sentence added by the system prompt
      - Trailing "Citations:" header lines left after stripping
      - Redundant horizontal rules (---)
    """
    import re, json as _json

    lines = text.split("\n")
    cleaned = []
    skip_next_blank = False

    for line in lines:
        stripped = line.strip()

        # Skip bare citation JSON blocks (lines that are a JSON object
        # containing source_url — i.e. the LLM-formatted citation blocks)
        if stripped.startswith("{") and "source_url" in stripped:
            skip_next_blank = True
            continue

        # Also handle multi-line JSON blocks: opening brace on its own line
        # followed by source_url — handled by collecting brace-started blocks
        # Skip [LOW CONFIDENCE] / [DATA COLLECTION MODE] warning lines
        # (rendered separately in the UI as confidence_warning)
        if stripped.startswith("[LOW CONFIDENCE]") or stripped.startswith("[DATA COLLECTION MODE]"):
            skip_next_blank = True
            continue

        # Skip "Citations:" header that the LLM sometimes inserts
        if re.match(r"^citations\s*:?\s*$", stripped, re.IGNORECASE):
            skip_next_blank = True
            continue

        # Skip the trailing disclaimer the system prompt appends
        if stripped.startswith("This information is for general guidance only"):
            skip_next_blank = True
            continue

        # Skip lone horizontal rules left after stripping
        if stripped in ("---", "──────────────────────────────────────────────────────────────────────────────"):
            skip_next_blank = True
            continue

        # Collapse consecutive blank lines created by stripping
        if stripped == "" and skip_next_blank:
            skip_next_blank = False
            continue

        skip_next_blank = False
        cleaned.append(line)

    # Remove leading/trailing blank lines
    result = "\n".join(cleaned).strip()
    return result


class SessionStore:
    """Simple in-memory session store. Suitable for demo/MVP."""

    def __init__(self):
        self._sessions: dict[str, dict] = {}

    def create(self) -> tuple[str, object, object]:
        """Create a new session. Returns (session_id, machine, session)."""
        from src.intake import IntakeStateMachine

        machine = IntakeStateMachine()
        session = machine.start_session()
        session_id = str(uuid.uuid4())
        self._sessions[session_id] = {"machine": machine, "session": session}
        return session_id

    def get(self, session_id: str) -> dict | None:
        return self._sessions.get(session_id)

    def exists(self, session_id: str) -> bool:
        return session_id in self._sessions


_store = SessionStore()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _profile_summary(profile) -> dict:
    """Return a display-friendly dict of collected profile fields."""
    from src.intake import REQUIRED_FIELDS, OPTIONAL_FIELDS, _FIELD_META

    d = profile.model_dump()
    required = []
    for f in REQUIRED_FIELDS:
        required.append({
            "field": f,
            "label": _FIELD_META[f]["label"],
            "value": d.get(f),
            "filled": d.get(f) is not None,
        })
    optional = []
    for f in OPTIONAL_FIELDS:
        val = d.get(f)
        if val is not None:
            optional.append({"field": f, "label": f.replace("_", " ").title(), "value": val})

    return {"required": required, "optional": optional}


# ---------------------------------------------------------------------------
# Routes — Static files
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return send_from_directory(str(WEB_DIR), "index.html")


# ---------------------------------------------------------------------------
# Routes — API
# ---------------------------------------------------------------------------

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


@app.route("/api/session", methods=["POST"])
def create_session():
    """Create a new intake session and return its ID + greeting message."""
    session_id = _store.create()
    data = _store.get(session_id)
    machine = data["machine"]
    session = data["session"]

    # Kick off with a greeting turn (empty message triggers GREETING state)
    turn = machine.process_turn(session, "")

    return jsonify({
        "session_id": session_id,
        "state": session.state.value,
        "agent_message": turn.agent_message,
        "profile": _profile_summary(session.profile),
        "ready_for_retrieval": False,
    })


@app.route("/api/chat", methods=["POST"])
def chat():
    """Process one conversation turn."""
    body = request.get_json(force=True) or {}
    session_id = body.get("session_id", "")
    message = body.get("message", "").strip()

    if not _store.exists(session_id):
        return jsonify({"error": "Session not found. Please refresh and start over."}), 404

    if not message:
        return jsonify({"error": "Empty message."}), 400

    data = _store.get(session_id)
    machine = data["machine"]
    session = data["session"]

    # ── Run intake turn ──────────────────────────────────────────────────────
    turn = machine.process_turn(session, message)

    base = {
        "session_id": session_id,
        "state": session.state.value,
        "profile": _profile_summary(session.profile),
        "ready_for_retrieval": turn.ready_for_retrieval,
        "action_route": turn.action_route.value if turn.action_route else None,
        "confidence_warning": turn.confidence_warning or "",
    }

    if not turn.ready_for_retrieval:
        # ── Intake still collecting ──────────────────────────────────────────
        base["type"] = "collecting"
        base["agent_message"] = turn.agent_message
        return jsonify(base)

    # ── Ready — run the full pipeline ────────────────────────────────────────
    try:
        from src.orchestrator import run_pipeline

        # Propagate the current user message into the profile query so that
        # detect_intent() and route_risk() in the pipeline operate on the
        # actual question, not the empty default.  (profile.query is not a
        # D-002 intake field so update_profile() never fills it.)
        session.profile.query = message
        answer = run_pipeline(session.profile)

        base["type"] = "answer"
        base["agent_message"] = turn.agent_message  # acknowledgment / transition msg
        base["answer"] = _clean_answer_text(answer.answer)
        base["risk_level"] = answer.risk_level.value
        base["action_type"] = answer.action_type.value if answer.action_type else None
        base["citations"] = [c.model_dump() for c in answer.citations]
        base["no_evidence_action"] = (
            answer.no_evidence_action.value if answer.no_evidence_action else None
        )
        base["confidence_warning"] = answer.confidence_warning or ""
        base["disclaimer"] = answer.disclaimer or ""
        base["retry_count"] = answer.retry_count

    except Exception as exc:  # noqa: BLE001 — surface errors to UI for demo
        base["type"] = "error"
        base["agent_message"] = (
            f"An error occurred while generating your answer: {exc}\n\n"
            "Please check that your .env file has valid LLM_ENDPOINT, LLM_API_KEY, "
            "and LLM_MODEL values, and that the retrieval index has been built."
        )

    return jsonify(base)


@app.route("/api/session/<session_id>", methods=["GET"])
def get_session(session_id: str):
    """Return current session state (profile + conversation state)."""
    if not _store.exists(session_id):
        return jsonify({"error": "Session not found."}), 404

    data = _store.get(session_id)
    session = data["session"]

    return jsonify({
        "session_id": session_id,
        "state": session.state.value,
        "turn_count": session.turn_count,
        "profile": _profile_summary(session.profile),
    })


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("Starting Canada PR Navigator web server on http://localhost:5050")
    print(f"Web UI:  http://localhost:5050/")
    print(f"API:     http://localhost:5050/api/health")
    app.run(host="0.0.0.0", port=5050, debug=True)


@app.route("/api/status", methods=["GET"])
def status():
    """Check whether the ChromaDB retrieval index is built and populated."""
    from pathlib import Path as _Path
    chroma_dir  = _Path(__file__).resolve().parent.parent / "chroma_db"
    chunks_file = _Path(__file__).resolve().parent.parent / "data" / "processed" / "chunks.jsonl"
    index_exists = chroma_dir.exists() and any(chroma_dir.iterdir()) if chroma_dir.exists() else False
    chunks_exist = chunks_file.exists()
    doc_count = 0
    if index_exists:
        try:
            import chromadb as _chromadb
            _c = _chromadb.PersistentClient(path=str(chroma_dir))
            doc_count = _c.get_or_create_collection("policy_chunks").count()
        except Exception:
            doc_count = -1
    return jsonify({
        "index_ready":  index_exists and doc_count > 0,
        "index_exists": index_exists,
        "chunks_file":  chunks_exist,
        "doc_count":    doc_count,
        "message": (
            f"Retrieval index loaded — {doc_count} chunks indexed."
            if doc_count > 0
            else "Retrieval index not built yet. Run: python -m src.ingestion_module"
        ),
    })
